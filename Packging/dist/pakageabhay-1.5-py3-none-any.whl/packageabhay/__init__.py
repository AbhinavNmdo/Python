class addition:
    def __init__(self):
        print("Your constructor is ready")
        
    def add(number, number2):
        print("Your addition is: ")
        return (number+number2)
