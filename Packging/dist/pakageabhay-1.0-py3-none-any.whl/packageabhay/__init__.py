class addition:
    def add(number, number2):
        print("Your addition is: ")
        return (number+number2)
